// BASSVERSE - FIXED FOOTER FUNCTION (Call number bhi hata diya)
  function footer() {
    var s = BV.getSettings();
    return '<footer class="site"><div class="wrap">' +
      '<div class="foot-grid">' +
      '<div><a class="logo" href="index.html">' + LOGO() + '<span class="word">BASS<span class="dim">VERSE</span></span></a>' +
      '<p class="muted tiny mt1" style="max-width:300px">' + BV.esc(s.tagline) + ' Premium wireless earbuds & headphones.</p>' +
      '<div class="row mt1">' +
      '<a class="btn btn-sm" href="' + BV.esc(s.instagram) + '" target="_blank" rel="noopener">Instagram</a>' +
      '<a class="btn btn-sm" href="' + BV.esc(s.facebook) + '" target="_blank" rel="noopener">Facebook</a>' +
      '</div></div>' +
      '<div><h4>Shop</h4><ul>' +
      '<li><a href="shop.html">All products</a></li>' +
      '<li><a href="shop.html?cat=Earbuds">Wireless Earbuds</a></li>' +
      '<li><a href="shop.html?cat=Headphones">Headphones</a></li>' +
      '<li><a href="shop.html?cat=Gaming">Gaming Headsets</a></li>' +
      '<li><a href="shop.html?cat=Accessories">Accessories</a></li>' +
      '<li><a href="shop.html?sort=best">Best Sellers</a></li>' +
      '</ul></div>' +
      '<div><h4>Help</h4><ul>' +
      '<li><a href="track.html">Track your order</a></li>' +
      '<li><a href="contact.html">Contact us</a></li>' +
      '<li><a href="faq.html">FAQ</a></li>' +
      '<li><a href="policies.html#shipping">Shipping policy</a></li>' +
      '<li><a href="policies.html#returns">Returns & refunds</a></li>' +
      '<li><a href="policies.html#warranty">Warranty</a></li>' +
      '</ul></div>' +
      '<div><h4>Get in touch</h4><ul>' +
      '<li><a href="mailto:' + BV.esc(s.email) + '" style="display:inline-flex;align-items:center;gap:9px">' +
        '<span style="width:26px;height:26px;border-radius:50%;border:1px solid var(--line2);display:grid;place-items:center;color:var(--gold);flex:0 0 auto">' +
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" style="width:13px;height:13px"><path d="M3 6h18v12H3z"/><path d="m3 7 9 6 9-6"/></svg></span>' +
        '<span>' + BV.esc(s.email) + '</span></a></li>' +
      '<li class="muted tiny">' + BV.esc(s.address) + '</li>' +
      '<li class="muted tiny">Mon–Sun, 10am – 10pm</li>' +
      '</ul></div>' +
      '</div>' +
      '<div class="foot-bottom"><span>© ' + new Date().getFullYear() + ' BASSVERSE. All rights reserved. · <a href="admin/index.html" style="color:var(--gold-l);font-weight:650">Admin Panel →</a></span>' +
      '</div></div></footer>';
  }
